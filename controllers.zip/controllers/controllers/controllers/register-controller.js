var connection = require('./../config');
var express=require('express');
var router=express.Router();

module.exports.register=function(req,res){

    connection.query('INSERT INTO test.login (username,phone,password,email,user_type) values (?,?,?,?,?)',[req.body.username,req.body.phone,req.body.password,req.body.email,req.body.type] ,function (error, results, fields) {
      if (error) {
        res.json({
           status:false,
            message:error,
			
        })
      }else{
          res.json({
            status:true,
            data:results,
            message:'User registered sucessfully'
        })
      }
    });
}