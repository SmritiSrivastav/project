var connection = require('./../config');
var express = require('express');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var app = express();
module.exports.authenticate=function(req,res){
	var choice=req.body.choice;
    var username=req.body.username;
    var password=req.body.password;
	var user_id;
	var sql='SELECT user_id,username,user_type,phone,email FROM login WHERE '+ choice +' = "'+ username+'" and password = "'+password+'";';
	console.log(sql);
    connection.query(sql,function (error, results, fields) {
      if (error) {
          res.json({
            status:false,
			title: error,
            message:"There is something wrong with the query"
            })
      }else{
        if(results.length >0){
			if(rows[0].user_type==1){
				connection.query({'select doctor_id from doctor where user_id_ref=?',[rows[0].user_id],function(errord,resultsd,fieldsd){
					if(errord){
					res.json({
				status:false,
				title: errord,
				message:"There is something wrong with the query"
            });	
					}
			else{
				user_id=resultsd[0].doctor_id;
			}
				}});
				
				
			}
			else{
				user_id=results[0].user_id;
			}
					var sessionData;
					/*app.get('/set_session',function(req,res){
									sessionData = req.session;
					sessionData.user = results;});*/
			app.use(cookieParser());
			app.use(session({results}));
            //if(password==results[0].password){
				
                res.json({
                    status:true,
                    message:'User authenticated',
					/*Object.keys(result).forEach(function(key) {
      var row = result[key];
      console.log(row.name)
    }*/
                });
            /*}else{
                res.json({
                  status:false,
                  message:"Username and password does not match"
                 });
            }*/
         
        }
       /* else{
          res.json({
              status:false, 			  
            message:"username does not exits "
          });
        }*/
      }
    });
}