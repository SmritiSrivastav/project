var express=require("express");
var bodyParser=require('body-parser');
var app = express();
//var logger = require('morgan');
var session = require('express-session');

var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
//const cors = require('cors');
var appointmentsRouter = require('./controllers/appointments');
//var usersRouter = require('./controllers/users');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
//app.use(cors());
app.use(session({resave: true, saveUninitialized: true, secret: 'XCR3rsasa%RDHHH', cookie: { maxAge: 60000 }}));

app.post('/api/register',registerController.register);
app.post('/api/authenticate',authenticateController.authenticate);
app.post('/api/appointments',appointmentsRouter.appointments);

//session destroy
app.get('/logout',function(req,res){
    sessionData = req.session;
    //res.json({sessionData});
    sessionData.destroy(function(err) {
        if(err){
            msg = 'Error destroying session';
            res.json(msg);
        }else{
            msg = 'Session destroy successfully';
            console.log(msg)
            res.json(msg);
        }
    });
});


//module.exports=app;
app.listen(8080)