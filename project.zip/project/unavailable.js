var connection = require('./../config');
var express=require('express');
var router=express.Router();
//doctor_id will come from session value
module.exports.register=function(req,res){
	var date=new Date();
	
	connection.query("insert into unavailable (doctor_id,date,details) values (?,?,?)",[req.body.doctor_id,date,req.body.details],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:errormain});}
		else{
			res.json({
			status:true,
			message: 'Value Saved !!'});
		}
	});
}